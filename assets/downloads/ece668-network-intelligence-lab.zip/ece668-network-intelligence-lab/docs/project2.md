# Project 2 · Predicting Network Demand

**Weeks 4–6 · 20% of the proposed course grade · Core environment: local CPU training**

A controller wants to anticipate the next interval's incoming traffic. Build a
small predictor and test whether its advantage survives a change in traffic
periodicity and bursts. This is a causal time-series task; it does not require
completing Project 1 or training a graph neural network.

## Concept notes

Let `x[t]` be the number of arriving packets in slot `t`. The forecasting problem
is `prediction[t] = f(x[t-6], ..., x[t-1])`. The target `x[t]` is not a feature.
Two useful baselines are persistence, which predicts the last observation, and
a moving mean, which smooths the six observations.

The supplied trained model is a regularized linear predictor. It standardizes
each feature using training-set mean and standard deviation, then minimizes
mean squared error plus a squared-weight penalty using gradient descent.
Standardization parameters are saved with the model. They must not be recomputed
using test observations, even when no test labels are involved.

Nearby windows from one trace share observations and dynamics. Randomly assigning
those windows to train and test can make a model appear more general than it is.
This package splits entire independently generated episodes before creating windows.

## Data contract

Every episode has 120 slots of synthetic packet counts. Training, validation,
and ordinary test episodes use a periodic Poisson rate with independently drawn
phase and samples. Shift episodes use a shorter period plus an additional burst.

| Split | Episode seeds | Role |
| --- | --- | --- |
| Train | 0–11 | Fit weights and scaling |
| Validation | 100–103 | Choose features and hyperparameters |
| Test | 200–205 | Final evaluation under the training distribution |
| Shift | 300–305 | Final distribution-shift evaluation |

In `dataset.csv`, `lag_1` is the **oldest** observation and `lag_6` the most recent.
`target_slot` identifies the next slot, and `target` is its arrival count.
The default feature vector contains six lags, their mean, and their range.
All values are generated locally; no operator traffic or personal data is included.

## Prelab

1. Write out the features and target for one seven-slot sequence.
2. Explain why using a centered smoothing window could reveal future information.
3. Give a case where persistence beats a long moving average.
4. Explain the difference between an unseen sample and an unseen traffic regime.
5. If a model helps predict traffic, what additional experiment is needed to show
   that using the prediction improves a network controller?

## Run and inspect

```sh
python3 -m ece668.project2 --out runs/p2-baseline
```

The command creates the data, trains a model, and writes `model.json`,
`manifest.json`, `metrics.csv`, `predictions.csv`, and a plot for the first
episode of each evaluation split. MAE and RMSE are in packets/slot. Predictions
are clipped at zero; this postprocessing is part of the baseline definition.

The supplied command emits all evaluation splits for convenient reproducibility.
During method development, choose settings using validation only. Freeze your
choice before interpreting the final test and shift results. The public seeds
are reproducibility fixtures, not a hidden grading set.

## Student implementation

Edit `forecast_features(history)` in `student/policies.py`. It receives only the
six observations preceding the target. Return a fixed-length numeric vector.
The initial student hook uses only the latest count; the shared trainer fits it.

```sh
python3 -m ece668.project2 --student --out runs/p2-student
```

Try a trend estimate, weighted average, differences, or a compact nonlinear
feature. To change the history length or model family, modify the data/training
code and document the new schema. Keep train-only preprocessing and episode splits.

## Required investigation

1. Compare persistence, moving mean, and the supplied trained predictor.
2. Develop one feature or model change with a clear network-related motivation.
3. Use validation data for model selection; retain a table of alternatives tried.
4. Report test and shift performance separately, including per-episode errors.
5. Show a failure interval and explain which assumption changed.
6. Perform an ablation: remove the feature or component claimed to help.

A model need not beat every baseline. Explain when prediction quality matters,
the cost of over- versus underprediction, and whether MAE matches that cost.
More training epochs or a larger model are not themselves a research contribution.

## Submit and assessment

Submit a saved model, feature code, data manifest, evaluation files, two figures,
and a 3–4 page report. Record training settings, selected validation configuration,
and the exact test command. State whether any test results influenced development.

| Criterion | Points |
| --- | --- |
| Causal features and correct split design | 25 |
| Training implementation and saved model | 25 |
| Baselines, ablation, and shift evaluation | 30 |
| Interpretation and reproducibility | 20 |

Optional extensions include congestion prediction, calibrated prediction intervals,
a small neural model, or recorded network traces with documented permission and
collection conditions. A real-data extension must split independent sessions and
explain what the target actually measures.
